package com.example.third.Exception;

public class NumberFormatEX extends RuntimeException {
    public NumberFormatEX (String message){
        super(message);
    }
    
}
