package com.example.third.Exception;



public class DuplicateException extends RuntimeException {
    public DuplicateException(String message){
        super(message);
    }
        
    
   
    
}
