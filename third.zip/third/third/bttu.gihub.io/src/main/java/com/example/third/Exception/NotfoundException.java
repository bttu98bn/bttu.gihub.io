package com.example.third.Exception;

public class NotfoundException extends RuntimeException {
    public NotfoundException(String Message){
        super(Message);
    }
    
}
